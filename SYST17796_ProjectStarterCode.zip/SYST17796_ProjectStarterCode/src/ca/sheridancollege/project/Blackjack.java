package ca.sheridancollege.project;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Noah
 */
import java.util.*;
import java.lang.*;
public class Blackjack {
    
        public static void main(String[] args) {
            
            Scanner input=new Scanner(System.in);
            Card[] playerHand=createHand.generateHand(2);
            Card[] dealerHand=createHand.generateHand(2);
            int playerHandTotal=0;
            int dealerHandTotal=0; 
            boolean turn =false;
            
            for(Card card:playerHand){
                if (card.getValue().toString()=="TWO")
                    playerHandTotal+=2;
                else if (card.getValue().toString()=="THREE")
                    playerHandTotal+=3;
                else if (card.getValue().toString()=="FOUR")
                    playerHandTotal+=4;
                else if (card.getValue().toString()=="FIVE")
                    playerHandTotal+=5;
                else if (card.getValue().toString()=="SIX")
                    playerHandTotal+=6;
                else if (card.getValue().toString()=="SEVEN")
                    playerHandTotal+=7;
                else if (card.getValue().toString()=="EIGHT")
                    playerHandTotal+=8;
                else if (card.getValue().toString()=="NINE")
                    playerHandTotal+=9;
                else if (card.getValue().toString()=="TEN"||card.getValue().toString()=="JACK"||
                    card.getValue().toString()=="QUEEN"||card.getValue().toString()=="KING")
                    playerHandTotal+=10;
                else if (card.getValue().toString()=="ACE")
                    playerHandTotal+=11;
            }
            for(Card card:dealerHand){
                if (card.getValue().toString()=="TWO")
                    dealerHandTotal+=2;
                else if (card.getValue().toString()=="THREE")
                    dealerHandTotal+=3;
                else if (card.getValue().toString()=="FOUR")
                    dealerHandTotal+=4;
                else if (card.getValue().toString()=="FIVE")
                    dealerHandTotal+=5;
                else if (card.getValue().toString()=="SIX")
                    dealerHandTotal+=6;
                else if (card.getValue().toString()=="SEVEN")
                    dealerHandTotal+=7;
                else if (card.getValue().toString()=="EIGHT")
                    dealerHandTotal+=8;
                else if (card.getValue().toString()=="NINE")
                    dealerHandTotal+=9;
                else if (card.getValue().toString()=="TEN"||card.getValue().toString()=="JACK"||
                    card.getValue().toString()=="QUEEN"||card.getValue().toString()=="KING")
                    dealerHandTotal+=10;
                else if (card.getValue().toString()=="ACE")
                    dealerHandTotal+=11;
                break;
            }
            
            // printing hands and game structure
            System.out.println("Welcome to Blackjack");
            System.out.println("--------------------");
            System.out.println("Dealer - "+dealerHandTotal);
            System.out.println("--------------------");
            for (Card card:dealerHand){
                System.out.println(card.getValue()+" of "+card.getSuit());
                break;
            }
            System.out.println("HIDDEN");
            System.out.println("\n\n\n");
            for (Card card:playerHand){
                System.out.println(card.getValue()+" of "+card.getSuit());
            }
            System.out.println("--------------------");
            System.out.println("YOUR HAND - TOTAL :"+playerHandTotal);
            
            
            //checks values and whether player can hit
            if (playerHandTotal<21){
                while(turn==false && playerHandTotal<21){
                System.out.println("\n\nType H to hit or S to stand");
                String decision = input.nextLine();
                if (decision.equalsIgnoreCase("h")){
                    Card[] newCard=createHand.generateHand(1);
                    for(Card card:newCard){
                        if (card.getValue().toString()=="TWO")
                    playerHandTotal+=2;
                else if (card.getValue().toString()=="THREE")
                    playerHandTotal+=3;
                else if (card.getValue().toString()=="FOUR")
                    playerHandTotal+=4;
                else if (card.getValue().toString()=="FIVE")
                    playerHandTotal+=5;
                else if (card.getValue().toString()=="SIX")
                    playerHandTotal+=6;
                else if (card.getValue().toString()=="SEVEN")
                    playerHandTotal+=7;
                else if (card.getValue().toString()=="EIGHT")
                    playerHandTotal+=8;
                else if (card.getValue().toString()=="NINE")
                    playerHandTotal+=9;
                else if (card.getValue().toString()=="TEN"||card.getValue().toString()=="JACK"||
                    card.getValue().toString()=="QUEEN"||card.getValue().toString()=="KING")
                    playerHandTotal+=10;
                else if (card.getValue().toString()=="ACE")
                    playerHandTotal+=11;
                    }
                System.out.println("Welcome to Blackjack");
            System.out.println("--------------------");
            System.out.println("Dealer - "+dealerHandTotal);
            System.out.println("--------------------");
            for (Card card:dealerHand){
                System.out.println(card.getValue()+" of "+card.getSuit());
                break;
            }
            System.out.println("HIDDEN");
            System.out.println("\n\n\n");
            for (Card card:playerHand){
                System.out.println(card.getValue()+" of "+card.getSuit());
            }
            System.out.println("--------------------");
            System.out.println("YOUR HAND - TOTAL :"+playerHandTotal);
                }
                
                else if(decision.equalsIgnoreCase("s") || playerHandTotal>21){
                    turn=true;
                }
                }
            }
            if (playerHandTotal==21){
                turn=true;
            }
            
            if (turn){
                while(dealerHandTotal<17){
                    Card[] newCard=createHand.generateHand(1);
                    for(Card card:newCard){
                    if (card.getValue().toString()=="TWO")
                    dealerHandTotal+=2;
                else if (card.getValue().toString()=="THREE")
                    dealerHandTotal+=3;
                else if (card.getValue().toString()=="FOUR")
                    dealerHandTotal+=4;
                else if (card.getValue().toString()=="FIVE")
                    dealerHandTotal+=5;
                else if (card.getValue().toString()=="SIX")
                    dealerHandTotal+=6;
                else if (card.getValue().toString()=="SEVEN")
                    dealerHandTotal+=7;
                else if (card.getValue().toString()=="EIGHT")
                    dealerHandTotal+=8;
                else if (card.getValue().toString()=="NINE")
                    dealerHandTotal+=9;
                else if (card.getValue().toString()=="TEN"||card.getValue().toString()=="JACK"||
                    card.getValue().toString()=="QUEEN"||card.getValue().toString()=="KING")
                    dealerHandTotal+=10;
                else if (card.getValue().toString()=="ACE")
                    dealerHandTotal+=11;
               }
                }
            System.out.println("--------------------");
            System.out.println("Dealer - "+dealerHandTotal);
            System.out.println("--------------------");
            for (Card card:dealerHand){
                System.out.println(card.getValue()+" of "+card.getSuit());
            }
            System.out.println("\n\n\n");
            for (Card card:playerHand){
                System.out.println(card.getValue()+" of "+card.getSuit());
            }
            System.out.println("--------------------");
            System.out.print("YOUR HAND - TOTAL :"+playerHandTotal);
            
            if (dealerHandTotal>21 || (playerHandTotal>dealerHandTotal && playerHandTotal<21)){
                System.out.println("you win!");
            }
            else if (playerHandTotal>21 || (dealerHandTotal>playerHandTotal && playerHandTotal<21)){
                System.out.println("dealer wins!");
            }
            else {
                System.out.println("TIE!");
            }
            }
        }
    
}
