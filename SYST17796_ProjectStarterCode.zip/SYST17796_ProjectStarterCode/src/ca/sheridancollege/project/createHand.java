/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ca.sheridancollege.project;
import java.util.*;
/**
 *
 * @author Noah
 */
public class createHand {
    
    public static Card[] generateHand(int cardNum){
        Card[] hand=new Card[cardNum];
        Random random=new Random();
        for(int i=0;i<hand.length;i++){
            Value value=Value.values()[random.nextInt(13)];
            Card.Suit suit=Card.Suit.values()[random.nextInt(4)];
            Card card = new Card(value,suit);
            hand[i]=card;
        }
        
        
        
        
        return hand;
    }
    
}
